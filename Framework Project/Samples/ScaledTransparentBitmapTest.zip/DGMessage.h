/*------------------------------------------------------------------------
File Name: DGMessage.h
Description: This file contains the DGMessage class, which represents
   a generic GUI message.
Version:
   1.0.0    10.02.2000  Created the file
------------------------------------------------------------------------*/


#ifndef DGMESSAGE_H
#define DGMESSAGE_H

class DGMessage
{

};

#endif
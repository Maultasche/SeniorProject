Left mouse double click closes the application
Right mouse single click changes the graphics mode between windowed and full-screen.
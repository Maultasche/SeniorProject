/*Main.cpp*/

#include <time.h>
#include "DxGuiFramework.h"

class DGSampleApplication : public DGApplication
{
public:
   void InitApp();
   void PreGUIDraw();
};

//User defines DxGuiApplication object
DGSampleApplication app;

//User lists overridden DxGuiApplication functions
void DGSampleApplication::InitApp()
{
   dgGraphics->SetGraphicsMode(DGPoint(640, 480), WS_WINDOWED,
      CD_16BIT, BT_DOUBLE, true);

   dgGraphics->LockSurface();
   dgGraphics->DrawVerticalLine(20, 20, 300, DGColor(156, 45, 101));
   dgGraphics->UnlockSurface();   

   srand((unsigned)time( NULL ));

}

void DGSampleApplication::PreGUIDraw()
{
   dgGraphics->LockSurface();
   
   int y1 = rand() % 480;
   int y2 = y1 + rand() % 480;
   if(y2 >= 480)
      y2 = 479;

   dgGraphics->DrawVerticalLine(rand() % 640, y1, y2, 
      DGColor(rand() % 255, rand() % 255, rand() % 255));
 
   dgGraphics->UnlockSurface();
}

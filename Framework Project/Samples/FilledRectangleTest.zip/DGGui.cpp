/*GUI.cpp*/

#include "DxGuiFramework.h"

//Constructor
DGGui::DGGui()
{
   OutputDebugString("GUI constructor\n");
}

//Destructor
DGGui::~DGGui()
{

}
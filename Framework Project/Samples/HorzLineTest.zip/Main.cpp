/*Main.cpp*/

#include <time.h>
#include "DxGuiFramework.h"

class DGSampleApplication : public DGApplication
{
public:
   void InitApp();
   void PreGUIDraw();
};

//User defines DxGuiApplication object
DGSampleApplication app;

//User lists overridden DxGuiApplication functions
void DGSampleApplication::InitApp()
{
   dgGraphics->SetGraphicsMode(DGPoint(640, 480), WS_WINDOWED,
      CD_16BIT, BT_DOUBLE, true);



   

   srand((unsigned)time( NULL ));

}

void DGSampleApplication::PreGUIDraw()
{
   dgGraphics->LockSurface();
   
   int x1 = rand() % 640;
   int x2 = x1 + rand() % 640;
   if(x2 >= 640)
      x2 = 639;

   dgGraphics->DrawHorizontalLine(x1, x2, rand() % 480, 
      DGColor(rand() % 255, rand() % 255, rand() % 255));
 
   dgGraphics->UnlockSurface();
}

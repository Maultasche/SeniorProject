/*------------------------------------------------------------------------
File Name: DGMainWindow.h
Description: This file contains the DGMainWindow class, which represent
   the main window in the GUI and is at the top of the window hierarchy.
Version:
   1.0.0    10.02.2000  Created the file
------------------------------------------------------------------------*/


#ifndef DGMAINWINDOW_H
#define DGMAINWINDOW_H

class DGMainWindow : public DGWindow
{

};

#endif
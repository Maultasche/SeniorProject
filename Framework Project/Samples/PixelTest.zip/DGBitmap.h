/*------------------------------------------------------------------------
File Name: DGBitmap.h
Description: This file contains the DGGBitmap class, which represents
	a bitmap stored in memory. An object of this class is able to load
	as well as store bitmaps.
Version:
   1.0.0    10.02.2000  Created the file
------------------------------------------------------------------------*/

#ifndef DGBITMAP_H
#define DGBITMAP_H

class DGBitmap
{

};

#endif
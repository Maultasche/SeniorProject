/*DxGuiTestApp.h*/

#ifndef DXGUITESTAPP_H
#define DXGUITESTAPP_H

#define	IDW_BLUEWINDOW			100
#define  IDW_REDWINDOW			101
#define	IDW_YELLOWWINDOW		102
#define	IDW_GREENWINDOW		103

class DxGuiTestApp : public DGApplication
{
public:
   void InitApp();
};

#endif
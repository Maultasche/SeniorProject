/*RedWindow.h*/

#ifndef REDWINDOW_H
#define REDWINDOW_H

class RedWindow : public DGWindow
{
public:
   RedWindow();
   RedWindow(int xPos, int yPos, int width, int height);

protected:
   void FC OnDrawWindow(DGSurface* surface);
   void FC OnMouseEnter(int x, int y, BYTE* keyboardState);
   void FC OnSetFocus(UINT winID);
   void FC OnLoseFocus(UINT winID);
   void FC OnLButtonDown(int x, int y, BYTE* keyboardState);
   void FC OnLButtonUp(int x, int y, BYTE* keyboardState);
   void FC OnMouseMove(int x, int y, BYTE* keyboardState);

private:
   DGPoint previousPosition;

   bool windowFocused;
   bool windowMoving;

#ifdef _DEBUG
   DGDebugLog debugLog;
#endif
};

#endif